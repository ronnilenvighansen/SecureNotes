import{c as s}from"./main-JfXWR_IP.js";const r=()=>s();export{r as u};
//# sourceMappingURL=useParams-CTk95xDM.js.map
