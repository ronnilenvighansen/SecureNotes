import{cd as o}from"./main-JfXWR_IP.js";const n=t=>r=>r&&o(t,r)||"—";export{n as t};
//# sourceMappingURL=translationFormatter-CBu3XkfN.js.map
